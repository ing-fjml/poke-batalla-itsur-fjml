# poke-batalla-itsur
Juego de batalla de pokemon para la materia Programación Orientada Objetos
